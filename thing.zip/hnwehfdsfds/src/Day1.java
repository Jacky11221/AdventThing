import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Day1 {
    public static void main(String[] args) {


        ArrayList<String> fileData = getFileData("src/day1Input.txt");

        ArrayList<String[]> h = new ArrayList<>();
        for(String data: fileData){
            h.add(convertTheStringToStrArrayUsingSplit(data));
        }
//        System.out.println(h.getFirst()[0]);

        for(int i = 0; i < h.size(); i++){
            System.out.println(h.get(i)[0]);
            System.out.println(h.get(i)[1]);
        }
        // list = Collection.sort(list)
        list = Collections.sort(list)
    }

    public static ArrayList<String> getFileData(String fileName) {
        ArrayList<String> fileData = new ArrayList<String>();
        try {
            File f = new File(fileName);
            Scanner s = new Scanner(f);
            while (s.hasNextLine()) {
                String line = s.nextLine();
                if (!line.isEmpty())
                    fileData.add(line);
            }
            return fileData;
        }
        catch (FileNotFoundException e) {
            return fileData;
        }
    }

//    public String[][] get2Array(String[] arr){
//        ArrayList<String> str1 = new ArrayList<>();
//        ArrayList<String> str2 = new ArrayList<>();
//
//    }


    public static String[] convertTheStringToStrArrayUsingSplit(String str){
        return str.split("   ");
    }

    public static ArrayList<String> sort(ArrayList<String> unsorted){
        int[] newArray;
        for(int i = 0; i < unsorted.size(); i++){
            int small = Integer.MIN_VALUE;
            for()
        }
    }
}